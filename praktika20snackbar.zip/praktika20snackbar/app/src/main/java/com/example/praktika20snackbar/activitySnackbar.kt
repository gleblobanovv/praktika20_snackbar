package com.example.praktika20snackbar

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class activitySnackbar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_snackbar)

        val button = findViewById<View>(R.id.button)
        button.setOnClickListener {
            click(it)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun click(view: View) {
        val snackbar = Snackbar.make(view, "Вы нажали кнопку", Snackbar.LENGTH_LONG)

        snackbar.setActionTextColor(ContextCompat.getColor(this, R.color.purple_500))

        snackbar.setAction("Next") {
            Toast.makeText(this, "Next clicked", Toast.LENGTH_LONG).show()
        }

        snackbar.show()
    }
}